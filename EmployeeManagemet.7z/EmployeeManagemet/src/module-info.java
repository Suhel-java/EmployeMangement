/**
 * 
 */
/**
 * 
 */
module EmployeeManagemet {
	requires java.sql;
}