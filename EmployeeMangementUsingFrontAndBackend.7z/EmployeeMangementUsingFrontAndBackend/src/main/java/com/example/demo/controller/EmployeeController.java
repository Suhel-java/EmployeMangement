package com.example.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;


@Controller
public class EmployeeController {
    @Autowired
    private EmployeeService service;

    @GetMapping("/")
    public String login() {
   		  return "menu";
    }

    @PostMapping("/menu")
    public String loginAction(@RequestParam String username,@RequestParam String password,Model model) {
        if(username.equals("sunil") && password.equals("1234")) {
        	return "menu";
        }
        model.addAttribute("error","Invalid Username & password");
        return "login";
    	
    }

    @GetMapping("/create")
    public String createPage(Model model) {
        model.addAttribute("employee", new Employee());
        return "create";
    }

    @PostMapping("/save")
    public String saveEmployee(@ModelAttribute Employee employee,
                               @RequestParam String choice) {
        service.saveEmployee(employee);

        if (choice.equalsIgnoreCase("yes")) {
            return "redirect:/create";
        }
        return "menu";
    }

    @GetMapping("/display")
    public String display(Model model) {
        model.addAttribute("employees", service.getAllEmployees());
        return "display";
    }

    @GetMapping("/raise")
    public String raisePage() {
        return "raise";
    }

    @PostMapping("/raiseSalary")
    public String raiseSalary(@RequestParam Long id,
                              @RequestParam double percent) {
        if (percent <= 10) {
            service.raiseSalary(id, percent);
        }
        return "menu";
    }

    @GetMapping("/exit")
    public String exit() {
        return "exit";
    }
}
