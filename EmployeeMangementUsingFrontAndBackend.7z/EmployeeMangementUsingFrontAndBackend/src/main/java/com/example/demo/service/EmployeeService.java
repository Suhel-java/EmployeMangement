package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository repo;

    public void saveEmployee(Employee emp) {
        if (emp.getDesignation().equalsIgnoreCase("programmer")) {
            emp.setSalary(25000);
        } else if (emp.getDesignation().equalsIgnoreCase("tester")) {
            emp.setSalary(15000);
        } else if (emp.getDesignation().equalsIgnoreCase("manager")) {
            emp.setSalary(30000);
        }
        repo.save(emp);
    }

    public List<Employee> getAllEmployees() {
        return repo.findAll();
    }

    public void raiseSalary(Long id, double percent) {
        Employee emp = repo.findById(id).get();
        double increment = emp.getSalary() * (percent / 100);
        emp.setSalary(emp.getSalary() + increment);
        repo.save(emp);
    }
}
